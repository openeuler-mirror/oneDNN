This is an implementation of jitdump format used by linux perf. The
[spec](https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/plain/tools/perf/Documentation/jitdump-specification.txt)
