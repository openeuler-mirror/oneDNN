This code is from [Intel(R) Single Event API (Intel(R) SEAPI) library](https://github.com/intel/IntelSEAPI)
